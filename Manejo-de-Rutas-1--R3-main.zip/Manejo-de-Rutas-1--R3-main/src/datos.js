const tareas = [
    {
      id: 1,
      titulo: 'Jugar a la pelota',
      descripcion: 'Juntarse con los chicos y nos vamos a la cancha.',
      fechaCreacion: '2024-09-26',
      estado: 'incompleta',
    },
    {
      id: 2,
      titulo: 'Hacer la tarea de Estanga',
      descripcion: 'Hacer los trabajos pendientes y armar el "Que sale".',
      fechaCreacion: '2024-09-25',
      estado: 'incompleta',
    },
    {
      id: 3,
      titulo: 'Ir a la escuela',
      descripcion: 'Todo muy tranquilo hoy en la escuela',
      fechaCreacion: '2024-09-25',
      estado: 'Completo',
    },
    
  ];
  
  export default tareas;
  